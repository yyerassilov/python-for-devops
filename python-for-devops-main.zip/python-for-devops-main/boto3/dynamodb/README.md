## Working With DynamoDB Using Boto3

This example shows loading sample data to dynamoDB and using boto3 to acess the data from the table.

Code Credits: [fernandomc.com Guide](https://www.fernandomc.com/posts/ten-examples-of-getting-data-from-dynamodb-with-python-and-boto3/)