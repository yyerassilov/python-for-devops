# Python for DevOps

If you want to understand the importance of python for DevOps, please read the [detailed python for DevOps guide](https://devopscube.com/python-for-devops/).

## Python Learning Resources

If you are looking for a guided way to learn Python from scratch., I recommend the following resources.

1. [learnpython.org](https://www.learnpython.org/)
2. [Learn Python 3 from Scratch](https://www.educative.io/courses/learn-python-3-from-scratch?aff=KNLz)
3. [Python for Beginners – Full Video Course](https://www.youtube.com/watch?v=eWRfhZUzrAc)
