import os

os.system('echo "hello"')