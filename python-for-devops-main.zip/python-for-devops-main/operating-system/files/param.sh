#!/bin/sh
echo $1
echo $2
echo $3

echo "$@"
exit 0