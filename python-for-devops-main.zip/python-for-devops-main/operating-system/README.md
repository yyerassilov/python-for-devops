## Python Operating Sytem Based Tasks

1. Create Directory
2. Delete Directory
3. List Directory
4. List total number of folder in a Directory
5. List total numbers of files in a Directory